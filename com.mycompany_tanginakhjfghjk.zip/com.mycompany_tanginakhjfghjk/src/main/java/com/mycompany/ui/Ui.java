package com.mycompany.ui;

import javax.swing.SwingUtilities;

public class Ui {

        public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SplashScreen());
    }
}
