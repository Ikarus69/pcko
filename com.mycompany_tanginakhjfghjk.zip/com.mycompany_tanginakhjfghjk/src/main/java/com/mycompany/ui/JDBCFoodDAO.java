/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ui;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;

public class JDBCFoodDAO implements FoodDAO {
    private Connection connection;
    
    public JDBCFoodDAO() {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:food_database.db");
            createTables();
            insertSampleData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void createTables() {
        String sql = "CREATE TABLE IF NOT EXISTS food_items (" +
                     "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                     "name TEXT NOT NULL," +
                     "category TEXT," +
                     "calories REAL," +
                     "protein REAL," +
                     "sugar REAL," +
                     "fat REAL," +
                     "image_path TEXT" +
                     ")";
        
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void insertSampleData() {
        try (Statement stmt = connection.createStatement()) {
            // Check if data already exists
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM food_items");
            if (rs.getInt(1) == 0) {
                // Insert sample data
                String insertSQL = "INSERT INTO food_items (name, category, calories, protein, sugar, fat, image_path) " +
                                  "VALUES ('Apple', 'Fruit', 95, 0.5, 19, 0.3, 'resources/apple.jpg'), " +
                                         "('Banana', 'Fruit', 105, 1.3, 14, 0.4, 'resources/banana.jpg'), " +
                                         "('Chicken Breast', 'Meat', 165, 31, 0, 3.6, 'resources/chicken.jpg'), " +
                                         "('Broccoli', 'Vegetable', 55, 3.7, 1.7, 0.6, 'resources/broccoli.jpg')";
                stmt.executeUpdate(insertSQL);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public List<FoodItem> getAllFoodItems() {
        List<FoodItem> items = new ArrayList<>();
        String sql = "SELECT * FROM food_items";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                items.add(createFoodItemFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return items;
    }
    
    @Override
    public FoodItem getFoodItemById(int id) {
        String sql = "SELECT * FROM food_items WHERE id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return createFoodItemFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    @Override
    public List<FoodItem> getFoodItemsByName(String name) {
        List<FoodItem> items = new ArrayList<>();
        String sql = "SELECT * FROM food_items WHERE name LIKE ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, "%" + name + "%");
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                items.add(createFoodItemFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return items;
    }
    
    @Override
    public void addFoodItem(FoodItem item) {
        String sql = "INSERT INTO food_items (name, category, calories, protein, sugar, fat, image_path) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, item.getName());
            pstmt.setString(2, item.getCategory());
            pstmt.setDouble(3, item.getCalories());
            pstmt.setDouble(4, item.getProtein());
            pstmt.setDouble(5, item.getSugar());
            pstmt.setDouble(6, item.getFat());
            pstmt.setString(7, item.getImagePath());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private FoodItem createFoodItemFromResultSet(ResultSet rs) throws SQLException {
        FoodItem item = new FoodItem();
        item.setId(rs.getInt("id"));
        item.setName(rs.getString("name"));
        item.setCategory(rs.getString("category"));
        item.setCalories(rs.getDouble("calories"));
        item.setProtein(rs.getDouble("protein"));
        item.setSugar(rs.getDouble("sugar"));
        item.setFat(rs.getDouble("fat"));
        item.setImagePath(rs.getString("image_path"));
        return item;
    }
}
