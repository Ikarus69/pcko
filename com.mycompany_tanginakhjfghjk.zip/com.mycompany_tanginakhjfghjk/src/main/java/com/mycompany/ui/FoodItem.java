package com.mycompany.ui;

public class FoodItem {
    private int id;
    private String name;
    private String category;
    private double calories;
    private double protein;
    private double sugar;
    private double fat;
    private String imagePath;

    // Constructors
    public FoodItem() {}

    public FoodItem(String name, String category, double calories, 
                    double protein, double sugar, double fat, String imagePath) {
        this.name = name;
        this.category = category;
        this.calories = calories;
        this.protein = protein;
        this.sugar = sugar;
        this.fat = fat;
        this.imagePath = imagePath;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public double getCalories() { return calories; }
    public void setCalories(double calories) { this.calories = calories; }
    public double getProtein() { return protein; }
    public void setProtein(double protein) { this.protein = protein; }
    public double getSugar() { return sugar; }
    public void setSugar(double sugar) { this.sugar = sugar; }
    public double getFat() { return fat; }
    public void setFat(double fat) { this.fat = fat; }
    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }
}
