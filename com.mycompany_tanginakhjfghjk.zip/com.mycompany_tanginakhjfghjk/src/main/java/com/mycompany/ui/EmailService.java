package com.mycompany.ui;

import jakarta.mail.Authenticator;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import javax.swing.JOptionPane;
import java.util.Properties;

public class EmailService {

    private static final String senderEmail = "mealplansystem201@gmail.com";
    private static final String senderPassword = "exmifjpzghbvavir";

    private static Session createSession() {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        return Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });
    }

    public static void sendVerificationCode(String recipientEmail, String verificationCode, String fullName) {
        String subject = "MealPlanner - Your Verification Code";
        String content = getStyledEmailContent(
                "Hi " + fullName + ",",
                "Thanks for registering! Use the verification code below to verify your email address:",
                verificationCode,
                "If you did not request this, please ignore this email."
        );
        sendEmail(recipientEmail, subject, content);
    }

    private static void sendEmail(String recipientEmail, String subject, String htmlContent) {
        try {
            Message message = new MimeMessage(createSession());
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject(subject);
            message.setContent(htmlContent, "text/html; charset=utf-8");

            Transport.send(message);
            System.out.println("Verification email sent to: " + recipientEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to send verification email. Please try again.");
        }
    }

    private static String getStyledEmailContent(String greeting, String message, String code, String footerNote) {
        return "<!DOCTYPE html>"
                + "<html><head><meta charset='UTF-8'><title>MealPlanner Verification</title></head>"
                + "<body style='margin:0; padding:0; font-family:Helvetica,Arial,sans-serif; background-color:#f4f4f4;'>"
                + "<div style='max-width:600px; margin:30px auto; background:#ffffff; border-radius:10px; overflow:hidden; box-shadow:0 4px 20px rgba(0,0,0,0.1);'>"
                + "<div style='background: linear-gradient(to right, #00b894, #00cec9); padding:20px; text-align:center;'>"
                + "<h1 style='color:white; margin:0;'>MealPlanner</h1>"
                + "</div>"
                + "<div style='padding:30px; text-align:center;'>"
                + "<h2 style='color:#2d3436;'>" + greeting + "</h2>"
                + "<p style='font-size:16px; color:#636e72;'>" + message + "</p>"
                + "<div style='margin:30px auto; width: fit-content; padding:20px 30px; background-color:#dfe6e9; border-radius:8px; font-size:26px; letter-spacing:6px; font-weight:bold; color:#2d3436;'>"
                + code
                + "</div>"
                + "<p style='font-size:14px; color:#b2bec3;'>" + footerNote + "</p>"
                + "</div>"
                + "<div style='background:#f1f2f6; text-align:center; padding:15px; font-size:12px; color:#8395a7;'>"
                + "Need help? Contact support at <a href='mailto:support@mealplanner.com' style='color:#00b894; text-decoration:none;'>support@mealplanner.com</a><br>"
                + "&copy; 2025 MealPlanner. All rights reserved."
                + "</div>"
                + "</div></body></html>";
    }
}
