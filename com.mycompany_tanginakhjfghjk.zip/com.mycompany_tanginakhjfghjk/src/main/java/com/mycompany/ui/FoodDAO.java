
package com.mycompany.ui;

/// FoodDAO.java
import java.util.List;

public interface FoodDAO {
    List<FoodItem> getAllFoodItems();
    FoodItem getFoodItemById(int id);
    List<FoodItem> getFoodItemsByName(String name);
    void addFoodItem(FoodItem item);
}
