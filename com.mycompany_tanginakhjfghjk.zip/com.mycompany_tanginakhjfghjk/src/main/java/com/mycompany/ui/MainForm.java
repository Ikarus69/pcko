/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ui;

// MainForm.java
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class MainForm extends javax.swing.JFrame {
    private FoodDAO foodDAO;
    private JTextField searchField;
    private JButton searchButton;
    private JTextArea resultTextArea;
    private JLabel imageLabel;
    private JButton addFoodButton;
    private JTable foodTable;
    private JScrollPane scrollPane;
    
    public MainForm() {
        initComponents();
        foodDAO = new JDBCFoodDAO();
        loadFoodItems();
    }
    
    private void initComponents() {
        // Instantiate components
        searchField = new JTextField(20);
        searchButton = new JButton("Search");
        resultTextArea = new JTextArea(10, 30);
        resultTextArea.setEditable(false);
        imageLabel = new JLabel();
        addFoodButton = new JButton("Add New Food");
        
        // Food table
        String[] columnNames = {"ID", "Name", "Category", "Calories", "Protein", "Sugar", "Fat"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        foodTable = new JTable(model);
        scrollPane = new JScrollPane(foodTable);
        
        // Set layout (using GroupLayout for this example)
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        
        // Horizontal layout
        layout.setHorizontalGroup(
            layout.createParallelGroup()
                .addGroup(layout.createSequentialGroup()
                    .addComponent(searchField)
                    .addComponent(searchButton))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(scrollPane)
                    .addGroup(layout.createParallelGroup()
                        .addComponent(imageLabel)
                        .addComponent(resultTextArea)))
                .addComponent(addFoodButton)
        );
        
        // Vertical layout
        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup()
                    .addComponent(searchField)
                    .addComponent(searchButton))
                .addGroup(layout.createParallelGroup()
                    .addComponent(scrollPane)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(imageLabel)
                        .addComponent(resultTextArea)))
                .addComponent(addFoodButton)
        );
        
        // Add action listeners
        searchButton.addActionListener(this::searchButtonActionPerformed);
        addFoodButton.addActionListener(this::addFoodButtonActionPerformed);
        
        // Configure window
        setTitle("Food Database");
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    
    private void loadFoodItems() {
        DefaultTableModel model = (DefaultTableModel) foodTable.getModel();
        model.setRowCount(0);
        
        List<FoodItem> items = foodDAO.getAllFoodItems();
        for (FoodItem item : items) {
            model.addRow(new Object[]{
                item.getId(),
                item.getName(),
                item.getCategory(),
                item.getCalories(),
                item.getProtein(),
                item.getSugar(),
                item.getFat()
            });
        }
    }
    
    private void searchButtonActionPerformed(ActionEvent evt) {
        String searchName = searchField.getText().trim();
        
        if (searchName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a food name to search");
            return;
        }
        
        List<FoodItem> matches = foodDAO.getFoodItemsByName(searchName);
        displaySearchResults(matches);
    }
    
    private void displaySearchResults(List<FoodItem> foods) {
        if (foods.isEmpty()) {
            resultTextArea.setText("No matching foods found.");
            imageLabel.setIcon(null);
            return;
        }
        
        // For simplicity, display first match
        FoodItem firstMatch = foods.get(0);
        
        try {
            // Load and display image
            ImageIcon icon = new ImageIcon(firstMatch.getImagePath());
            Image scaledImage = icon.getImage().getScaledInstance(
                imageLabel.getWidth(), -1, Image.SCALE_SMOOTH);
            imageLabel.setIcon(new ImageIcon(scaledImage));
            
            // Display nutrition info
            StringBuilder sb = new StringBuilder();
            sb.append("Name: ").append(firstMatch.getName()).append("\n");
            sb.append("Category: ").append(firstMatch.getCategory()).append("\n");
            sb.append("Calories: ").append(firstMatch.getCalories()).append(" kcal\n");
            sb.append("Protein: ").append(firstMatch.getProtein()).append("g\n");
            sb.append("Sugar: ").append(firstMatch.getSugar()).append("g\n");
            sb.append("Fat: ").append(firstMatch.getFat()).append("g\n");
            
            resultTextArea.setText(sb.toString());
        } catch (Exception e) {
            resultTextArea.setText("Error displaying food information.");
            e.printStackTrace();
        }
    }
    
    private void addFoodButtonActionPerformed(ActionEvent evt) {
        // Create input dialog for new food
        JTextField nameField = new JTextField();
        JTextField categoryField = new JTextField();
        JTextField caloriesField = new JTextField();
        JTextField proteinField = new JTextField();
        JTextField sugarField = new JTextField();
        JTextField fatField = new JTextField();
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Food Image");
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.addChoosableFileFilter(
            new FileNameExtensionFilter("Image files", ImageIO.getReaderFileSuffixes()));
        
        Object[] message = {
            "Name:", nameField,
            "Category:", categoryField,
            "Calories:", caloriesField,
            "Protein (g):", proteinField,
            "Sugar (g):", sugarField,
            "Fat (g):", fatField,
            "Image:", fileChooser
        };
        
        int option = JOptionPane.showConfirmDialog(
            this, message, "Add New Food", JOptionPane.OK_CANCEL_OPTION);
        
        if (option == JOptionPane.OK_OPTION) {
            try {
                // Get selected image path (if any)
                String imagePath = "";
                if (fileChooser.getSelectedFile() != null) {
                    imagePath = fileChooser.getSelectedFile().getPath();
                }
                
                FoodItem newFood = new FoodItem(
                    nameField.getText(),
                    categoryField.getText(),
                    Double.parseDouble(caloriesField.getText()),
                    Double.parseDouble(proteinField.getText()),
                    Double.parseDouble(sugarField.getText()),
                    Double.parseDouble(fatField.getText()),
                    imagePath
                );
                
                foodDAO.addFoodItem(newFood);
                loadFoodItems();
                JOptionPane.showMessageDialog(this, "Food added successfully!");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, 
                    "Please enter valid numbers for nutritional values", 
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainForm().setVisible(true);
        });
    }
}
