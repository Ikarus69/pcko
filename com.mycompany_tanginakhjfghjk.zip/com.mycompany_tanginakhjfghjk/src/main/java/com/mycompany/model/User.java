package com.mycompany.model;

public class User {
    private int userId;
    private String email;
    private String fullName;
    private String username;
    private String password;
    private int age;
    private double height;
    private double weight;
    private double bmi;
    private String gender;
    private String birthdate;
    private String goal;
    private String dietType;
    private String allergies;
    private String verificationToken;
    private boolean isVerified;

    // Default constructor
    public User() {}

    // Constructor with only email and fullName
    public User(String email, String fullName) {
        this.email = email;
        this.fullName = fullName;
    }

    // Full constructor - useful for creating User objects from DB fully populated
    public User(int userId, String email, String fullName, String username, String password,
                int age, double height, double weight, double bmi, String gender,
                String birthdate, String goal, String dietType, String allergies,
                String verificationToken, boolean isVerified) {
        this.userId = userId;
        this.email = email;
        this.fullName = fullName;
        this.username = username;
        this.password = password;
        this.age = age;
        this.height = height;
        this.weight = weight;
        this.bmi = bmi;
        this.gender = gender;
        this.birthdate = birthdate;
        this.goal = goal;
        this.dietType = dietType;
        this.allergies = allergies;
        this.verificationToken = verificationToken;
        this.isVerified = isVerified;
    }

    // Getters and Setters
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public double getHeight() { return height; }
    public void setHeight(double height) { this.height = height; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }

    public double getBmi() { return bmi; }
    public void setBmi(double bmi) { this.bmi = bmi; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getBirthdate() { return birthdate; }
    public void setBirthdate(String birthdate) { this.birthdate = birthdate; }

    public String getGoal() { return goal; }
    public void setGoal(String goal) { this.goal = goal; }

    public String getDietType() { return dietType; }
    public void setDietType(String dietType) { this.dietType = dietType; }

    public String getAllergies() { return allergies; }
    public void setAllergies(String allergies) { this.allergies = allergies; }

    public String getVerificationToken() {
        return verificationToken;
    }
    public void setVerificationToken(String verificationToken) {
        this.verificationToken = verificationToken;
    }

    public boolean isVerified() {
        return isVerified;
    }
    public void setVerified(boolean verified) {
        isVerified = verified;
    }

    @Override
    public String toString() {
        return "User {" +
                "userId=" + userId +
                ", email='" + email + '\'' +
                ", fullName='" + fullName + '\'' +
                ", username='" + username + '\'' +
                ", age=" + age +
                ", height=" + height +
                ", weight=" + weight +
                ", bmi=" + bmi +
                ", gender='" + gender + '\'' +
                ", birthdate='" + birthdate + '\'' +
                ", goal='" + goal + '\'' +
                ", dietType='" + dietType + '\'' +
                ", allergies='" + allergies + '\'' +
                ", verificationToken='" + verificationToken + '\'' +
                ", isVerified=" + isVerified +
                '}';
    }
}
