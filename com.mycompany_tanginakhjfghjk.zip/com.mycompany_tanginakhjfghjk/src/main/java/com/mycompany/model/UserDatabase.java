package com.mycompany.model;

import java.util.HashMap;
import java.util.Map;

public class UserDatabase {
    private static Map<String, String> users = new HashMap<>();

    public static boolean registerUser(String email, String password) {
        if (users.containsKey(email)) {
            return false; // already registered
        }
        users.put(email, password);
        return true;
    }

    public static boolean authenticate(String email, String password) {
        return users.containsKey(email) && users.get(email).equals(password);
    }
}
