package dao;

import com.mycompany.model.User;
import java.sql.*;

public class UserInfoDAO {
    private final Connection connection;

    public UserInfoDAO(Connection connection) {
        this.connection = connection;
    }

    // Get user info by email, joining users and user_info tables
    public User getUserInfoByEmail(String email) throws SQLException {
        String sql = "SELECT u.id, u.email, u.full_name, ui.age, ui.gender, ui.birthdate, ui.height, ui.weight, ui.bmi, ui.goal, ui.diet_type, ui.allergies " +
                     "FROM users u " +
                     "LEFT JOIN user_info ui ON u.id = ui.user_id " +
                     "WHERE u.email = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                User user = new User(rs.getString("email"), rs.getString("full_name"));
                user.setUserId(rs.getInt("id"));
                user.setAge(rs.getInt("age"));
                user.setGender(rs.getString("gender"));
                user.setBirthdate(rs.getString("birthdate"));
                user.setHeight(rs.getDouble("height"));
                user.setWeight(rs.getDouble("weight"));
                user.setBmi(rs.getDouble("bmi")); // Added setting of bmi
                user.setGoal(rs.getString("goal"));
                user.setDietType(rs.getString("diet_type"));
                user.setAllergies(rs.getString("allergies"));
                return user;
            }
        }
        return null; // Not found
    }

    // Check if user exists
    public boolean userExists(int userId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0; // Returns true if user exists
            }
        }
        return false; // User does not exist
    }

    // Save or update user info (upsert)
    public void saveUserInfo(User user) throws SQLException {
        if (!userExists(user.getUserId())) {
            throw new SQLException("User with ID " + user.getUserId() + " does not exist.");
        }
        String sql = "INSERT INTO user_info (user_id, age, height, weight, bmi, gender, birthdate, goal, diet_type, allergies) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " + // 10 placeholders
                     "ON DUPLICATE KEY UPDATE age = ?, height = ?, weight = ?, bmi = ?, gender = ?, birthdate = ?, goal = ?, diet_type = ?, allergies = ?"; // 9 placeholders

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, user.getUserId());
            stmt.setInt(2, user.getAge());
            stmt.setDouble(3, user.getHeight());
            stmt.setDouble(4, user.getWeight());
            stmt.setDouble(5, user.getBmi());
            stmt.setString(6, user.getGender());
            stmt.setString(7, user.getBirthdate());
            stmt.setString(8, user.getGoal());
            stmt.setString(9, user.getDietType());
            stmt.setString(10, user.getAllergies());

            // For ON DUPLICATE KEY UPDATE params (same order as above, starting from 11)
            stmt.setInt(11, user.getAge());
            stmt.setDouble(12, user.getHeight());
            stmt.setDouble(13, user.getWeight());
            stmt.setDouble(14, user.getBmi());
            stmt.setString(15, user.getGender());
            stmt.setString(16, user.getBirthdate());
            stmt.setString(17, user.getGoal());
            stmt.setString(18, user.getDietType());
            stmt.setString(19, user.getAllergies());

            stmt.executeUpdate();
        }
    }
}
