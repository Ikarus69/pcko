package dao;

import com.mycompany.model.User;
import java.sql.*;

public class UserDAO {
    private final Connection connection;

    public UserDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean saveUser (User user) {
        String sql = "INSERT INTO users (email, full_name, username, password) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, user.getEmail());
            stmt.setString(2, user.getFullName());
            stmt.setString(3, user.getUsername());
            stmt.setString(4, user.getPassword());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) return false;

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    user.setUserId(generatedKeys.getInt(1)); // Ensure userId is set
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public User authenticate(String email, String password) {
        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    User user = new User(email, rs.getString("full_name"));
                    user.setUserId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(password);

                    // Load extended info from user_info
                    loadUserInfo(user);

                    return user;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Load extended info from user_info table
    private void loadUserInfo(User user) {
        String sql = "SELECT age, birthdate, height, weight, allergies, gender, goal, diet_type FROM user_info WHERE user_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, user.getUserId());
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    user.setAge(rs.getInt("age"));
                    user.setBirthdate(rs.getString("birthdate"));
                    user.setHeight(rs.getDouble("height"));
                    user.setWeight(rs.getDouble("weight"));
                    user.setAllergies(rs.getString("allergies"));
                    user.setGender(rs.getString("gender"));
                    user.setGoal(rs.getString("goal"));
                    user.setDietType(rs.getString("diet_type"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update both users and user_info tables
    public boolean updateUser (User user) {
        String updateUserSql = "UPDATE users SET full_name = ?, username = ? WHERE id = ?";
        String updateInfoSql = "UPDATE user_info SET age = ?, birthdate = ?, height = ?, weight = ?, allergies = ?, gender = ?, goal = ?, diet_type = ? WHERE user_id = ?";

        try {
            connection.setAutoCommit(false);

            try (PreparedStatement userStmt = connection.prepareStatement(updateUserSql)) {
                userStmt.setString(1, user.getFullName());
                userStmt.setString(2, user.getUsername());
                userStmt.setInt(3, user.getUserId());
                userStmt.executeUpdate();
            }

            try (PreparedStatement infoStmt = connection.prepareStatement(updateInfoSql)) {
                infoStmt.setInt(1, user.getAge());
                infoStmt.setString(2, user.getBirthdate());
                infoStmt.setDouble(3, user.getHeight());
                infoStmt.setDouble(4, user.getWeight());
                infoStmt.setString(5, user.getAllergies());
                infoStmt.setString(6, user.getGender());
                infoStmt.setString(7, user.getGoal());
                infoStmt.setString(8, user.getDietType());
                infoStmt.setInt(9, user.getUserId());
                infoStmt.executeUpdate();
            }

            connection.commit();
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}
