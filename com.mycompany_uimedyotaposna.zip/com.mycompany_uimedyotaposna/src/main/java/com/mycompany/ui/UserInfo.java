package com.mycompany.ui;

import com.mycompany.model.User;
import dao.UserInfoDAO;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.SQLException;

public class UserInfo {
    private final User user;
    private JTextField fullNameField, ageField, birthdateField, heightField, weightField, allergiesField, bmiField;
    private JComboBox<String> genderBox, goalBox, dietTypeBox;

    private JFrame frame;
    private Connection dbConnection; // Database connection

    // Constructor for logged user
    public UserInfo(User loggedUser , Connection connection) {
        this.user = loggedUser ;
        this.dbConnection = connection;

        initUI();
        populateFields();
        setFieldsEditable(false);
        frame.setVisible(true);
    }

    private void initUI() {
        frame = new JFrame("User  Information");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1550, 800);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(240, 240, 240));

        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(new Color(40, 40, 40));
        leftPanel.setBounds(0, 0, 150, frame.getHeight());
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        frame.add(leftPanel);
        leftPanel.add(Box.createVerticalStrut(200));

        String[] navTitles = {"DASHBOARD", "MEAL PLAN", "SCHEDULE", "PROGRESS", "NOTIFICATION"};
        for (String title : navTitles) {
            JButton navButton = new JButton(title);
            navButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            navButton.setMaximumSize(new Dimension(120, 40));
            navButton.setFocusPainted(false);
            navButton.setForeground(Color.WHITE);
            navButton.setBackground(new Color(60, 60, 60));
            navButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            navButton.setBorder(new RoundedBorder(10));
            leftPanel.add(navButton);
            leftPanel.add(Box.createVerticalStrut(70));
        }

        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(Color.WHITE);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(null);
        mainPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
        mainPanel.setBounds(150, 20, frame.getWidth() - 170, frame.getHeight() - 40);
        frame.add(mainPanel);

        ImageIcon icon = new ImageIcon("C:/Users/THINKPAD/Pictures/Screenshots/pfp.jpg");
        Image circularImage = createCircularImage(icon.getImage(), 120);
        JLabel profilePic = new JLabel(new ImageIcon(circularImage));
        profilePic.setBounds(100, 30, 120, 120);
        mainPanel.add(profilePic);

        JLabel dashboardTitle = new JLabel("User  Information");
        dashboardTitle.setFont(new Font("Arial", Font.BOLD, 30));
        dashboardTitle.setBounds(250, 70, 300, 50);
        mainPanel.add(dashboardTitle);

        // Form fields
        fullNameField = createTextField(250, 350, 300);
        ageField = createTextField(250, 400, 300);
        genderBox = createComboBox(new String[]{"Male", "Female"}, 250, 450, 300);
        birthdateField = createTextField(250, 500, 300);
        heightField = createTextField(800, 350, 300);
        weightField = createTextField(800, 400, 300);
        goalBox = createComboBox(new String[]{"Lose Weight", "Maintain", "Gain Muscle"}, 800, 450, 300);
        dietTypeBox = createComboBox(new String[]{"Vegetarian", "Vegan", "Keto", "Paleo"}, 800, 500, 300);
        allergiesField = createTextField(250, 550, 300);
        bmiField = createTextField(250, 600, 300);
        bmiField.setEditable(false); // Make BMI field read-only

        // Add labels and fields
        mainPanel.add(createLabel("Full Name:", 150, 350)); mainPanel.add(fullNameField);
        mainPanel.add(createLabel("Age:", 150, 400)); mainPanel.add(ageField);
        mainPanel.add(createLabel("Gender:", 150, 450)); mainPanel.add(genderBox);
        mainPanel.add(createLabel("Birthdate:", 150, 500)); mainPanel.add(birthdateField);
        mainPanel.add(createLabel("Height (cm):", 700, 350)); mainPanel.add(heightField);
        mainPanel.add(createLabel("Weight (kg):", 700, 400)); mainPanel.add(weightField);
        mainPanel.add(createLabel("Goal:", 700, 450)); mainPanel.add(goalBox);
        mainPanel.add(createLabel("Diet Type:", 700, 500)); mainPanel.add(dietTypeBox);
        mainPanel.add(createLabel("Allergies:", 150, 550)); mainPanel.add(allergiesField);
        mainPanel.add(createLabel("BMI:", 150, 600)); mainPanel.add(bmiField);

        Font emojiFont = new Font("Segoe UI Emoji", Font.PLAIN, 14);
        JButton editButton = createButton("✍️ EDIT", 1030, 100, 120, emojiFont);
        JButton saveButton = createButton("💽 SAVE", 1170, 100, 120, emojiFont);
        JButton signOutButton = createButton("🚪 SIGN OUT", 1170, 670, 150, emojiFont);

        for (JButton btn : new JButton[]{editButton, saveButton, signOutButton}) {
            btn.setBackground(Color.WHITE);
            btn.setForeground(Color.BLACK);
            btn.setFocusPainted(false);
            btn.setBorder(new RoundedBorder(10));
        }

        mainPanel.add(editButton);
        mainPanel.add(saveButton);
        mainPanel.add(signOutButton);

        // Add live BMI calculation when height or weight changes
        DocumentListener bmiCalcListener = new DocumentListener() {
            void updateBMI() {
                try {
                    double h = Double.parseDouble(heightField.getText().trim());
                    double w = Double.parseDouble(weightField.getText().trim());
                    if (h > 0 && w > 0) {
                        double bmi = w / ((h / 100) * (h / 100));
                        bmiField.setText(String.format("%.2f", bmi));
                        user.setBmi(bmi);
                    } else {
                        bmiField.setText("");
                        user.setBmi(0);
                    }
                } catch (NumberFormatException ex) {
                    bmiField.setText("");
                    user.setBmi(0);
                }
            }

            @Override public void insertUpdate(DocumentEvent e) { updateBMI(); }
            @Override public void removeUpdate(DocumentEvent e) { updateBMI(); }
            @Override public void changedUpdate(DocumentEvent e) { updateBMI(); }
        };

        heightField.getDocument().addDocumentListener(bmiCalcListener);
        weightField.getDocument().addDocumentListener(bmiCalcListener);

        // Edit button action
        editButton.addActionListener(e -> setFieldsEditable(true));

        // Save button action
        saveButton.addActionListener(e -> {
            try {
                // Validate inputs
                String fullName = fullNameField.getText().trim();
                if (fullName.isEmpty()) throw new IllegalArgumentException("Full Name cannot be empty.");
                int age = Integer.parseInt(ageField.getText().trim());
                if (age <= 0) throw new IllegalArgumentException("Age must be positive.");
                String birthdate = birthdateField.getText().trim();
                if (birthdate.isEmpty()) throw new IllegalArgumentException("Birthdate cannot be empty.");
                double height = Double.parseDouble(heightField.getText().trim());
                if (height <= 0) throw new IllegalArgumentException("Height must be positive.");
                double weight = Double.parseDouble(weightField.getText().trim());
                if (weight <= 0) throw new IllegalArgumentException("Weight must be positive.");

                // Update user model fields
                user.setFullName(fullName);
                user.setAge(age);
                user.setBirthdate(birthdate);
                user.setHeight(height);
                user.setWeight(weight);
                user.setAllergies(allergiesField.getText().trim());
                user.setGender((String) genderBox.getSelectedItem());
                user.setGoal((String) goalBox.getSelectedItem());
                user.setDietType((String) dietTypeBox.getSelectedItem());

                // Save to database
                UserInfoDAO dao = new UserInfoDAO(dbConnection);
                dao.saveUserInfo(user);

                setFieldsEditable(false);
                JOptionPane.showMessageDialog(frame, "User  information saved successfully!");
            } catch (NumberFormatException ne) {
                JOptionPane.showMessageDialog(frame, "Please enter valid numbers for Age, Height, and Weight.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ie) {
                JOptionPane.showMessageDialog(frame, ie.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException sqle) {
                JOptionPane.showMessageDialog(frame, "Database error: " + sqle.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                sqle.printStackTrace();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Unexpected error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        signOutButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure you want to sign out?", "Confirm Sign Out", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                frame.dispose();
                // handle sign out logic
            }
        });

        // Responsive resizing
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int w = frame.getWidth();
                int h = frame.getHeight();
                leftPanel.setBounds(0, 0, 150, h);
                mainPanel.setBounds(150, 20, w - 170, h - 40);
                frame.repaint();
            }
        });
    }

    private void populateFields() {
        fullNameField.setText(user.getFullName());
        ageField.setText(String.valueOf(user.getAge()));
        birthdateField.setText(user.getBirthdate());
        heightField.setText(String.valueOf(user.getHeight()));
        weightField.setText(String.valueOf(user.getWeight()));
        allergiesField.setText(user.getAllergies());
        genderBox.setSelectedItem(user.getGender());
        goalBox.setSelectedItem(user.getGoal());
        dietTypeBox.setSelectedItem(user.getDietType());
        bmiField.setText(user.getBmi() > 0 ? String.format("%.2f", user.getBmi()) : "");
    }

    private void setFieldsEditable(boolean editable) {
        fullNameField.setEditable(editable);
        ageField.setEditable(editable);
        birthdateField.setEditable(editable);
        heightField.setEditable(editable);
        weightField.setEditable(editable);
        allergiesField.setEditable(editable);
        bmiField.setEditable(false); // BMI is readonly always
        genderBox.setEnabled(editable);
        goalBox.setEnabled(editable);
        dietTypeBox.setEnabled(editable);
    }

    private JLabel createLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, 120, 30);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        return label;
    }

    private JTextField createTextField(int x, int y, int width) {
        JTextField textField = new JTextField();
        textField.setBounds(x, y, width, 30);
        return textField;
    }

    private JComboBox<String> createComboBox(String[] options, int x, int y, int width) {
        JComboBox<String> comboBox = new JComboBox<>(options);
        comboBox.setBounds(x, y, width, 30);
        return comboBox;
    }

    private JButton createButton(String text, int x, int y, int width, Font font) {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, 30);
        button.setFont(font);
        return button;
    }

    private Image createCircularImage(Image image, int diameter) {
        BufferedImage masked = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = masked.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setClip(new Ellipse2D.Float(0, 0, diameter, diameter));
        g2.drawImage(image.getScaledInstance(diameter, diameter, Image.SCALE_SMOOTH), 0, 0, null);
        g2.dispose();
        return masked;
    }

    private static class RoundedBorder extends AbstractBorder {
        private final int radius;

        public RoundedBorder(int radius) {
            this.radius = radius;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.GRAY);
            g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(radius + 2, radius + 2, radius + 2, radius + 2);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.set(radius + 2, radius + 2, radius + 2, radius + 2);
            return insets;
        }
    }

    public static void main(String[] args) {
        // Replace 'yourDatabaseConnection' with actual Connection object
        SwingUtilities.invokeLater(() -> {
            User demoUser  = new User("demo@example.com", "Demo User");
            demoUser .setUserId(1); // Set a demo user ID
            demoUser .setAge(25);
            demoUser .setBirthdate("1998-01-01");
            demoUser .setHeight(175.0);
            demoUser .setWeight(70.0);
            demoUser .setAllergies("None");
            demoUser .setGender("Male");
            demoUser .setGoal("Maintain");
            demoUser .setDietType("Vegetarian");
            demoUser .setBmi(22.86); // Set a demo BMI value
            // Pass a valid database connection here
            new UserInfo(demoUser , /* yourDatabaseConnection */ null);
        });
    }
}
