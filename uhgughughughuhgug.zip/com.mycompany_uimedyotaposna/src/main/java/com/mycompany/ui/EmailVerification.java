package com.mycompany.ui;

import com.mycompany.model.User;
import dao.UserDAO;
import database.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;

public class EmailVerification {
    private final String sentCode;
    private final String userEmail;

    public EmailVerification(String email, String sentCode) {
        this.sentCode = sentCode;
        this.userEmail = email;

        JFrame frame = new JFrame("Email Verification");
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;
        frame.setSize(screenWidth, screenHeight);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds((screenWidth - 400) / 2, (screenHeight - 350) / 2, 400, 350);
        panel.setLayout(null);
        frame.setContentPane(panel);

        JLabel titleLabel = new JLabel("EMAIL VERIFICATION", SwingConstants.CENTER);
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setBounds(70, 50, 250, 20);
        panel.add(titleLabel);

        JLabel codeLabel = new JLabel("Enter the 6-digit verification code sent to your email:");
        codeLabel.setForeground(Color.BLACK);
        codeLabel.setFont(new Font("Arial", Font.BOLD, 12));
        codeLabel.setBounds(30, 110, 340, 20);
        panel.add(codeLabel);

        JTextField codeField = new JTextField();
        codeField.setBounds(50, 135, 300, 30);
        panel.add(codeField);

        JButton verifyButton = new JButton("Verify");
        verifyButton.setForeground(Color.WHITE);
        verifyButton.setBackground(Color.BLACK);
        verifyButton.setFont(new Font("Arial", Font.PLAIN, 12));
        verifyButton.setBounds(130, 180, 140, 30);
        panel.add(verifyButton);

        verifyButton.addActionListener(e -> {
            if (codeField.getText().trim().equals(sentCode)) {
                try (Connection conn = DatabaseConnection.getConnection()) {
                    UserDAO userDAO = new UserDAO(conn);
                    boolean updated = userDAO.markUserVerified(userEmail);
                    if (updated) {
                        // Retrieve full User instance for next form
                        User verifiedUser = userDAO.getUserByEmail(userEmail); // Implement getUserByEmail

                        JOptionPane.showMessageDialog(frame, "Verification successful! You can now proceed.");
                        frame.dispose();

                        if (verifiedUser != null) {
                            new FillUpForm(verifiedUser);
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to load user details.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, "Failed to update verification status.");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Database error occurred.");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Incorrect verification code.");
            }
        });

        frame.setVisible(true);
    }
}
