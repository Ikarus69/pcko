package com.mycompany.ui;


import java.util.Random;

public class PasswordResetManager {
    private static String email;
    private static String verificationCode;

    public static void setEmail(String userEmail) {
        email = userEmail;
        generateVerificationCode();
    }

    public static String getEmail() {
        return email;
    }

    public static void generateVerificationCode() {
        Random rand = new Random();
        verificationCode = String.format("%06d", rand.nextInt(1000000));
        System.out.println("Verification code sent to email: " + verificationCode);
    }

    public static boolean verifyCode(String inputCode) {
        return verificationCode != null && verificationCode.equals(inputCode);
    }

    public static void reset() {
        email = null;
        verificationCode = null;
    }
}

