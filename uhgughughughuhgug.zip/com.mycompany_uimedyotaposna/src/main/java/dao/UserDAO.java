package dao;

import com.mycompany.model.User;
import java.sql.*;

public class UserDAO {
    private final Connection connection;

    public UserDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean saveUser (User user) {
        String sql = "INSERT INTO users (email, full_name, username, password, verification_token, is_verified) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, user.getEmail());
            stmt.setString(2, user.getFullName());
            stmt.setString(3, user.getUsername());
            stmt.setString(4, user.getPassword());
            stmt.setString(5, user.getVerificationToken());
            stmt.setBoolean(6, user.isVerified());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) return false;

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    user.setUserId(generatedKeys.getInt(1));
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public User authenticate(String email, String password) {
        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    if (!rs.getBoolean("is_verified")) {
                        return null; // User is not verified
                    }

                    User user = new User(email, rs.getString("full_name"));
                    user.setUserId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(password);
                    loadUserInfo(user);
                    return user;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void loadUserInfo(User user) {
        String sql = "SELECT age, birthdate, height, weight, allergies, gender, goal, diet_type, bmi FROM user_info WHERE user_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, user.getUserId());
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    user.setAge(rs.getInt("age"));
                    user.setBirthdate(rs.getString("birthdate"));
                    user.setHeight(rs.getDouble("height"));
                    user.setWeight(rs.getDouble("weight"));
                    user.setAllergies(rs.getString("allergies"));
                    user.setGender(rs.getString("gender"));
                    user.setGoal(rs.getString("goal"));
                    user.setDietType(rs.getString("diet_type"));
                    user.setBmi(rs.getDouble("bmi"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean updateUser (User user) {
        String updateUserSql = "UPDATE users SET full_name = ?, username = ?, is_verified = ? WHERE id = ?";
        String updateInfoSql = "UPDATE user_info SET age = ?, birthdate = ?, height = ?, weight = ?, allergies = ?, gender = ?, goal = ?, diet_type = ?, bmi = ? WHERE user_id = ?";

        try {
            connection.setAutoCommit(false);

            try (PreparedStatement userStmt = connection.prepareStatement(updateUserSql)) {
                userStmt.setString(1, user.getFullName());
                userStmt.setString(2, user.getUsername());
                userStmt.setBoolean(3, user.isVerified());
                userStmt.setInt(4, user.getUserId());
                userStmt.executeUpdate();
            }

            try (PreparedStatement infoStmt = connection.prepareStatement(updateInfoSql)) {
                infoStmt.setInt(1, user.getAge());
                infoStmt.setString(2, user.getBirthdate());
                infoStmt.setDouble(3, user.getHeight());
                infoStmt.setDouble(4, user.getWeight());
                infoStmt.setString(5, user.getAllergies());
                infoStmt.setString(6, user.getGender());
                infoStmt.setString(7, user.getGoal());
                infoStmt.setString(8, user.getDietType());
                infoStmt.setDouble(9, user.getBmi());
                infoStmt.setInt(10, user.getUserId());
                infoStmt.executeUpdate();
            }

            connection.commit();
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public boolean updateVerificationToken(User user) {
        String sql = "UPDATE users SET verification_token = ? WHERE email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, user.getVerificationToken());
            stmt.setString(2, user.getEmail());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public User verifyUser (String token) {
        String sql = "SELECT * FROM users WHERE verification_token = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, token);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User user = new User(rs.getString("email"), rs.getString("full_name"));
                user.setUserId(rs.getInt("id"));
                user.setVerified(true);
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to mark a user as verified based on their email
    public boolean markUserVerified(String email) {
        String sql = "UPDATE users SET is_verified = TRUE WHERE email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, email);
            return stmt.executeUpdate() > 0; // Return true if the update was successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if there was an error
        }
    }

    // Method to retrieve a user by email
    public User getUserByEmail(String email) {
        String sql = "SELECT * FROM users WHERE email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setUserId(rs.getInt("id"));
                    user.setEmail(rs.getString("email"));
                    user.setFullName(rs.getString("full_name"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setVerified(rs.getBoolean("is_verified"));
                    user.setVerificationToken(rs.getString("verification_token"));
                    // Load other fields if needed or from user_info in another query
                    return user;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
